package org.kickmyb.server.account;

public class BadCredentialsException extends Exception {
}
